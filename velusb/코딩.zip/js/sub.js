$(function () {


















    }) //제이쿼이 전체 끝
